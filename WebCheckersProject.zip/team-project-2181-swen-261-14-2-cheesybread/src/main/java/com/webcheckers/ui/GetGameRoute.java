package com.webcheckers.ui;

import com.webcheckers.model.Game;
import com.webcheckers.model.Player;
import spark.*;
import com.webcheckers.appl.GameCenter;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class GetGameRoute implements Route {

    static final String VIEW_NAME = "game.ftl";
    static final String TITLE = "Game Page";
    static final String TITLE_ATTR = "title";
    static final String PLAYER_ATTR = "player";
    static final String MSG_ATTR = "message";

    private final TemplateEngine templateEngine;
    private GameCenter gameCenter;

    private enum ViewMode { PLAY, SPECTATOR, REPLAY };

    public GetGameRoute(final GameCenter gameCenter, final TemplateEngine templateEngine) {

        Objects.requireNonNull(templateEngine, "Template Engine must not be null");
        this.templateEngine = templateEngine;
        this.gameCenter = gameCenter;
    }

    @Override
    public Object handle(Request request, Response response) {
        //current session
        final Session http = request.session();

        Map<String, Object> vm = new HashMap<>();
        vm.put(TITLE_ATTR, TITLE);

        final Player player = http.attribute(PLAYER_ATTR);

        if (http.isNew()){
            response.redirect("/"); // new sessions should go to the homepage to log in
        }

        vm.put("currentPlayer", player);

        Game game = gameCenter.getGame(player);

        vm.put("redPlayer", game.getRedPlayer());
        vm.put("whitePlayer", game.getWhitePlayer());
        vm.put("activeColor", game.getActiveColor());
        vm.put("viewMode", ViewMode.PLAY);
        vm.put("board", game.getBoard());

        return templateEngine.render(new ModelAndView(vm, VIEW_NAME));
    }

}
