package com.webcheckers.ui;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.logging.Logger;

import com.webcheckers.appl.GameCenter;
import com.webcheckers.appl.PlayerLobby;
import com.webcheckers.model.Message;
import spark.ModelAndView;
import spark.Request;
import spark.Response;
import spark.Route;
import spark.TemplateEngine;

import com.webcheckers.appl.PlayerLobby;
import com.webcheckers.model.Player;
import spark.*;

/**
 * The UI Controller to GET the Home page.
 *
 * @author <a href='mailto:bdbvse@rit.edu'>Bryan Basham</a>
 */
public class GetHomeRoute implements Route {
  private static final Logger LOG = Logger.getLogger(GetHomeRoute.class.getName());

  private final TemplateEngine templateEngine;
  private final PlayerLobby playerLobby;
  private GameCenter gameCenter;

  static final String TITLE_ATTR = "title";
  static final String TITLE = "Welcome!";
  static final String PLAYER_ATTR = "player";
  static final String NUMOFPLAYERS_ATTR = "numberOfPlayers";
  static final String VIEW_HOME = "home.ftl";
  static final String SIGNEDIN_ATTR = "signedIn";
  static final String PLAYER_NAME = "playerName";
  static final String PLAYER_LIST = "playerList";
  static final String FULLPLAYER_LIST = "fullPlayerList";

  /**
   * Create the Spark Route (UI controller) for the
   * {@code GET /} HTTP request.
   *
   * @param templateEngine
   *   the HTML template rendering engine
   */
  public GetHomeRoute(final PlayerLobby playerLobby, final GameCenter gameCenter, final TemplateEngine templateEngine) {
    // validation
    Objects.requireNonNull(templateEngine, "templateEngine must not be null");
    //
    this.playerLobby = playerLobby;
    this.gameCenter = gameCenter;
    this.templateEngine = templateEngine;
    //
    LOG.config("GetHomeRoute is initialized.");
  }

  /**
   * Render the WebCheckers Home page.
   *
   * @param request
   *   the HTTP request
   * @param response
   *   the HTTP response
   *
   * @return
   *   the rendered HTML for the Home page
   */
  @Override
  public Object handle(Request request, Response response) {
    //current session
      final Session http = request.session();

    LOG.finer("GetHomeRoute is invoked.");
    //
    Map<String, Object> vm = new HashMap<>();
    vm.put(TITLE_ATTR, TITLE);
    vm.put(NUMOFPLAYERS_ATTR, playerLobby.getNumOfPlayers());

    //current player
      final Player player = http.attribute(PLAYER_ATTR);

      if (http.isNew()){
          http.attribute(PLAYER_ATTR, playerLobby.newPlayer());
          vm.put(SIGNEDIN_ATTR, false);
      }
      else{
          String opponent = request.queryParams("opponent");
          if (opponent != null) {
              Player opponentPlayer = playerLobby.getPlayer(opponent);
              if (opponentPlayer.getIsInGame()) {
                  player.setRejected(true);
              }else {
                  gameCenter.startGame(player, opponentPlayer);
              }
          }

          if(player.isRejected()){
              vm.put("message", new Message("Player is already in a game.", Message.Type.error));
          }
          if(!player.isRejected() && playerLobby.isSignedIn(player)){
              vm.put("message", new Message("You have successfully signed in!", Message.Type.info));
          }
          vm.put(SIGNEDIN_ATTR, playerLobby.isSignedIn(player));
          vm.put(PLAYER_NAME, player.getName());
          vm.put(PLAYER_LIST, playerLobby.getUpdatedPlayerList(player));
          vm.put(FULLPLAYER_LIST, playerLobby.getPlayerList());

          if(player.getIsInGame()){
              response.redirect("/game");
          }
      }

    return templateEngine.render(new ModelAndView(vm , VIEW_HOME));
  }

}