/**
 * Created by jmh7693 on 10/11/2018
 */
package com.webcheckers.ui;

import spark.*;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class GetSignInRoute implements Route{

    static final String VIEW_NAME = "signin.ftl";
    static final String TITLE = "Sign In Page";
    static final String TITLE_ATTR = "title";
    static final String MSG_ATTR = "message";

    private final TemplateEngine templateEngine;

    /**
     * creates the spark route
     * @param templateEngine
     */
    public GetSignInRoute(final TemplateEngine templateEngine){

        //non null validation
        Objects.requireNonNull(templateEngine, "template engine must not be null");
        this.templateEngine = templateEngine;
    }

    /**
     * renders the sign in page
     * @param request http request
     * @param response http response
     * @return
     */
    @Override
    public Object handle(Request request, Response response){
        Map<String, Object> vm = new HashMap<>();
        vm.put(TITLE_ATTR, TITLE);
        vm.put(GetHomeRoute.SIGNEDIN_ATTR, false);

        return templateEngine.render(new ModelAndView(vm, VIEW_NAME));
    }
}
