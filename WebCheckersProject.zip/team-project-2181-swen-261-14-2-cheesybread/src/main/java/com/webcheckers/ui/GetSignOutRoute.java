/**
 * Created by jmh7693 on 10/11/2018
 */
package com.webcheckers.ui;

import com.webcheckers.appl.PlayerLobby;
import com.webcheckers.model.Message;
import com.webcheckers.model.Player;
import spark.*;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/**
 * Class in charge of signing the player out of the player lobby
 */
public class GetSignOutRoute implements Route{

    static final String MSG_ATTR = "message";
    static final String SIGNOUT_MSG = "You have successfully signed out!";

    private final TemplateEngine templateEngine;

    /**
     * creates the spark route
     * @param templateEngine
     */
    public GetSignOutRoute(final TemplateEngine templateEngine){
        Objects.requireNonNull(templateEngine, "templateEngine must not be null.");
        this.templateEngine = templateEngine;
    }

    /**
     * handles the signout http request
     * @param request http request
     * @param response http response
     * @return signed out view
     */
    @Override
    public Object handle(Request request, Response response){

        Map<String, Object> vm = new HashMap<>();
        vm.put(GetHomeRoute.TITLE_ATTR, GetHomeRoute.TITLE);

        final Session session = request.session();
        final Player player = session.attribute(GetHomeRoute.PLAYER_ATTR);

        ModelAndView mv;

        player.signOut();

        vm.put(GetHomeRoute.SIGNEDIN_ATTR, Boolean.FALSE);
        vm.put(MSG_ATTR, new Message(SIGNOUT_MSG, Message.Type.info));
        vm.put(GetHomeRoute.PLAYER_NAME, player.getName());

        mv = new ModelAndView(vm, GetHomeRoute.VIEW_HOME);

        response.redirect("/");

        return templateEngine.render(mv);
    }


}
