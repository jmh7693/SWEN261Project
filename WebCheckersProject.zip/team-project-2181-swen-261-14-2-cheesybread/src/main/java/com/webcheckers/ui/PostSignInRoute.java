/**
 * Created by jmh7693 on 10/11/2018
 */
package com.webcheckers.ui;

import com.webcheckers.appl.PlayerLobby;
import com.webcheckers.model.Message;
import com.webcheckers.model.Player;
import spark.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import static spark.Spark.halt;

public class PostSignInRoute implements Route{

    static final String NAME_ATTR = "name";
    static final String MSG_ATTR = "message";
    static final String NAMEUSED_ERROR_MSG = "That name is already in use.";
    static final String NAMEINVALID_ERROR_MSG = "That name is invalid. Must use only alphanumeric characters. No spaces before or after Name.";
    static final String SIGNIN_MSG = "You have successfully signed in!";

    private final TemplateEngine templateEngine;

    /**
     * creates the spark route
     * @param templateEngine
     */
    public PostSignInRoute(final TemplateEngine templateEngine){
        Objects.requireNonNull(templateEngine, "templateEngine must not be null.");
        this.templateEngine = templateEngine;
    }

    /**
     * handles the post sign in http request
     * @param request http request
     * @param response http response
     * @return
     */
    @Override
    public Object handle(Request request, Response response){
        Map<String, Object> vm = new HashMap<>();
        vm.put(GetHomeRoute.TITLE_ATTR, GetHomeRoute.TITLE);

        final Session session = request.session();
        final Player player = session.attribute(GetHomeRoute.PLAYER_ATTR);

        final String nameInput = request.queryParams(NAME_ATTR);

        ModelAndView mv;

        if (player.signIn(nameInput)){
            response.redirect("/");
            return null;
        }
        else if(!player.checkName(nameInput)){
            Message msg = new Message(NAMEINVALID_ERROR_MSG, Message.Type.error);
            vm.put(GetHomeRoute.SIGNEDIN_ATTR, Boolean.FALSE);
            vm.put(MSG_ATTR, msg);
            mv = new ModelAndView(vm, GetSignInRoute.VIEW_NAME);
        }
        else{
            Message msg = new Message(NAMEUSED_ERROR_MSG, Message.Type.error);
            vm.put(GetHomeRoute.SIGNEDIN_ATTR, Boolean.FALSE);
            vm.put(MSG_ATTR, msg);
            mv = new ModelAndView(vm, GetSignInRoute.VIEW_NAME);
        }
        return templateEngine.render(mv);
    }

}
