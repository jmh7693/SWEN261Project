package com.webcheckers.appl;

import com.webcheckers.model.Game;
import com.webcheckers.model.Player;

import java.util.HashMap;
import java.util.Map;

public class GameCenter {

    private Map<String, Game> games = new HashMap<>();

    public boolean startGame(Player redPlayer, Player whitePlayer) {
        if (games.containsKey(redPlayer.getName()) || games.containsKey(whitePlayer.getName()))
            return false;

        if (redPlayer.equals(whitePlayer)) return false; // can't play yourself

        Game game = new Game(redPlayer, whitePlayer);
        games.put(redPlayer.getName(), game);
        games.put(whitePlayer.getName(), game);

        return true;
    }

    public Game getGame(Player player) {
        return games.get(player.getName());
    }

    public void gameOver(Game game) {
        if (games.containsValue(game)) {
            games.remove(game.getRedPlayer().getName());
            games.remove(game.getWhitePlayer().getName());
            game.getRedPlayer().setIsInGame(false);
            game.getWhitePlayer().setIsInGame(false);
        }
    }

}
