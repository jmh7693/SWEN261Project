package com.webcheckers.appl;


import com.webcheckers.model.Player;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;
import java.util.logging.Logger;

/**
 * This object keeps track of the state of the web application and its players
 */
public class PlayerLobby {

    private static final Logger LOG = Logger.getLogger(PlayerLobby.class.getName());

    private HashMap<String, Player> playerMap = new HashMap();
    private int numOfPlayers = 0;

    /**
     * creates a new player
     * @return new player object
     */
    public Player newPlayer()
    {
        LOG.fine("New Player instance created.");
        return new Player(this);
    }

    /**
     * checks is a name is valid or not
     * @param name being checked
     * @return (True is yes, False if not)
     */
    public Boolean isNameValid(String name){
        if (name.length() == name.trim().length() && !name.matches("^.*[^a-zA-Z0-9 ].*$"))
            return true;
        else
            return false;
    }

    public Boolean isSignedIn(Player player){
        return playerMap.containsKey(player.getName()) ? true : false;
    }

    public int getNumOfPlayers(){
        return this.numOfPlayers;
    }

    public Set getPlayerList(){
        return playerMap.keySet();
    }

    /**
     * Attempts to sign a player into the lobby
     *
     * @param player that is attempting to sign in
     * @return if the attempt was successful or not
     */
    public Boolean signIn(String name, Player player){
        if(!playerMap.containsKey(name) && isNameValid(name)){
            playerMap.put(name, player);
            player.setName(name);
            numOfPlayers = playerMap.size();
            return true;
        }
        else
            return false;
    }

    public Boolean signOut(Player player){
        if(playerMap.containsValue(player)){
            if(player.getIsInGame()){
                player.setIsInGame(false);
            }
            player.setRejected(false);
            playerMap.remove(player.getName());
            numOfPlayers = playerMap.size();
            return true;

        }
        return false;

    }

    public Set getUpdatedPlayerList(Player player){
        HashMap<String, Player> map = (HashMap<String, Player>) playerMap.clone();
        for(String playerName : playerMap.keySet()){
            if (playerMap.get(playerName).getIsInGame()){
                map.remove(playerName);
            }
        }
        map.remove(player.getName());
        return map.keySet();
    }

    public Player getPlayer(String name){
        return playerMap.get(name);
    }
}
