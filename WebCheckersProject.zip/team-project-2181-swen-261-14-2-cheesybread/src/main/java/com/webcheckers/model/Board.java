package com.webcheckers.model;

import java.util.ArrayList;
import java.util.Iterator;

public class Board implements Iterable<Row> {

    // Attributes
    private ArrayList<Row> rows = new ArrayList<>();
    private Player redPlayer;
    private Player whitePlayer;


    // Constructor
    public Board(Player player1, Player player2) {
        this.redPlayer = player1;
        this.whitePlayer = player2;
        int r;
        int c;
        for(r = 0; r < 8; r++) {
            rows.add(new Row(r));
            for(c = 0; c < 8; c += 2){
                if(r < 3 && (r % 2) == 0){
                    rows.get(r).spaces.add(c, new Space(c, null, false));
                    rows.get(r).spaces.add(c+1, new Space(c+1, new Piece(redPlayer, Piece.Color.RED, r, c+1), true));
                } else if (r < 3) {
                    rows.get(r).spaces.add(c,new Space(c, new Piece(redPlayer, Piece.Color.RED, r, c), true));
                    rows.get(r).spaces.add(c+1, new Space(c+1, null, false));
                } else if (r > 4 && (r % 2) == 0) {
                    rows.get(r).spaces.add(c,new Space(c, null, false));
                    rows.get(r).spaces.add(c+1, new Space(c+1, new Piece(whitePlayer, Piece.Color.WHITE, r, c+1), true));
                } else if (r > 4) {
                    rows.get(r).spaces.add(c,new Space(c, new Piece(whitePlayer, Piece.Color.WHITE, r, c), true));
                    rows.get(r).spaces.add(c+1,new Space(c+1, null, false));
                } else if (r == 3) {
                    rows.get(r).spaces.add(c,new Space(c, null, true));
                    rows.get(r).spaces.add(c+1,new Space(c+1, null, false));
                } else {
                    rows.get(r).spaces.add(c,new Space(c, null, false));
                    rows.get(r).spaces.add(c+1,new Space(c+1, null, true));
                }
            }
        }
    }

    // Methods
    public Iterator<Row> iterator(){
        return rows.iterator();
    }
    
    public void movePiece(Space space, int row, int column){
        if(row >= 0 && row <= 7 && column >= 0 && column <= 7 && rows.get(row).spaces.get(column).isValid()) {
            Piece movedPiece = space.getPiece();
            movedPiece.changePosition(row, column);
            rows.get(row).spaces.get(column).piece = movedPiece;
            space.piece = null;
        }
    }

    public Piece pieceAt(int row, int column){
        return rows.get(row).spaces.get(column).getPiece();
    }
}

