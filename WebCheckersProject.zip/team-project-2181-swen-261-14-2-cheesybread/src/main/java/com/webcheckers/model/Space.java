package com.webcheckers.model;

// Space Nested Class
public class Space {
    private int index;
    protected Piece piece;
    protected boolean validSpace; // Whether a piece can be placed here or not

    public Space(int index, Piece piece, boolean validity){
        this.index = index;
        this.piece = piece;
        this.validSpace = validity;
    }

    public int getCellIdx() { return this.index; }

    public boolean isValid() { return validSpace && piece == null; }

    public Piece getPiece() { return piece; }
}
