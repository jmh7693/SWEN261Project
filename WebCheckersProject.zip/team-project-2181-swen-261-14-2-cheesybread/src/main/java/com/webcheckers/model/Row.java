package com.webcheckers.model;

import java.util.ArrayList;
import java.util.Iterator;

// Row Nested Class
public class Row implements Iterable<Space> {
    private int index;
    protected ArrayList<Space> spaces = new ArrayList<>();

    public Row(int index){
        this.index = index;
    }

    public int getIndex(){ return this.index; }

    public Iterator<Space> iterator(){
        return spaces.iterator();
    }
}
