package com.webcheckers.model;

public class Game {

    private Player redPlayer, whitePlayer;
    private Board board;

    private Piece.Color activeColor;

    public Game(Player redPlayer, Player whitePlayer) {
        this.redPlayer = redPlayer;
        this.whitePlayer = whitePlayer;
        board = new Board(redPlayer, whitePlayer);
        activeColor = Piece.Color.RED;
        redPlayer.setIsInGame(true);
        whitePlayer.setIsInGame(true);
    }

    public Player getRedPlayer() {
        return redPlayer;
    }

    public Player getWhitePlayer() {
        return whitePlayer;
    }

    public Piece.Color getActiveColor() {
        return activeColor;
    }

    public Board getBoard() {
        return board;
    }

}
