package com.webcheckers.model;


public class Message {

    private String text;
    private Type type;

    /**
     * defines the enum based on message type
     */
    public enum Type{
        info, error
    }

    /**
     * Constructor for message class
     * @param text in the message
     * @param type of message
     */
    public Message(String text, Type type){
        this.text = text;
        this.type = type;
    }

    /**
     * get the text within a message
     * @return message's text
     */
    public String getText(){
        return text;
    }

    /**
     * get the type of a message
     * @return message's type
     */
    public Type getType(){
        return type;
    }
}
