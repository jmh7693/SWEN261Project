/**
 * Created by jmh7693 on 10/11/2018
 */
package com.webcheckers.model;

import com.webcheckers.appl.PlayerLobby;

import java.util.Objects;
import java.util.logging.Logger;

/**
 * represents a single player object
 */
public class Player {

    private static final Logger LOG = Logger.getLogger(Player.class.getName());

    private PlayerLobby playerLobby;
    //player's name
    private String name;
    //value tells in a player is in a game or not
    private boolean isInGame;
    //tells if a player was rejected from starting a game
    private boolean rejected = false;




    /**
     * constructor for Player
     * @param playerLobby -> the lobby of players
     */
    public Player(PlayerLobby playerLobby){
        this.playerLobby = playerLobby;
        isInGame = false;
    }

    /**
     * Gets the player's name
     * @return the player's name
     */
    public String getName(){
        return this.name;
    }

    /**
     * Sets a player's name
     * @param name
     */
    public void setName(String name){
        LOG.fine("Updated player name: " + name);
        this.name = name;
    }

    /**
     * returns whether a player is in a game or not
     * @return True if in game, False if not
     */
    public boolean getIsInGame(){
        return this.isInGame;
    }

    /**
     * Sets a player's game status
     * @param inGame (True if yes, False if not)
     */
    public void setIsInGame(boolean inGame){
        isInGame = inGame;
    }

    /**
     * tells of the player was rejected from a game
     * @return (True if yes, False if not)
     */
    public boolean isRejected(){
        return rejected;
    }

    /**
     * sets if a player is rejected from a game or not
     * @param rejected (True if yes, False if not)
     */
    public void setRejected(boolean rejected){
        this.rejected = rejected;
    }

    /**
     * attempts to sign a player in
     * @param name of the player
     * @return (True upon success, False upon failure)
     */
    public boolean signIn(String name){
        return playerLobby.signIn(name, this);
    }

    /**
     * checks is a player's name is valid
     * @param name of the player
     * @return (True if valid, False if not)
     */
    public boolean checkName(String name){
        return playerLobby.isNameValid(name);
    }

    /**
     * signs the player out of the lobby
     */
    public void signOut(){
        playerLobby.signOut(this);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Player player = (Player) o;
        return Objects.equals(name, player.name);
    }
}
