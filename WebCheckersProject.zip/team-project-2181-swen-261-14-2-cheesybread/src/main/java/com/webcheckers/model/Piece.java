package com.webcheckers.model;

public class Piece {

    // Enums 
    public enum Color {RED, WHITE}

    public enum Type {SINGLE, KING}

    // Attributes 
    private Player owner;
    private Color color;
    private Type type;
    private int row;
    private int column;

    // Constructor 
    public Piece(Player owner, Color color, int row, int column){
        this.owner = owner;
        this.type = Type.SINGLE;
        this.row = row;
        this.column = column;
        this.color = color;
    }

    // Methods 
    public Player getOwner() {return owner;}
    public Color getColor() {return color;}
    public Type getType() {return type;}
    public int getRow() {return row;}
    public int getColumn() {return column;}

    public void changePosition(int row, int column){
        if(row < 0 || row > 7 || column < 0 || column > 7) {
            return;
        }
        this.row = row;
        this.column = column;
    }

    public void promote() {
        if(row == 7 && color.equals(Color.RED)){ type = Type.KING; }
        else if(row == 0 && color.equals(Color.WHITE)) { type = Type.KING; }
    }

    @Override
    public boolean equals(Object obj){
        if(obj == this){return true;}
        else if(!(obj instanceof Piece)) {return false;}
        else {
            final Piece that = (Piece) obj;
            return that.getRow() == row && that.getColumn() == column && that.getType().equals(type) && that.getColor().equals(color);
        }
    }
}
