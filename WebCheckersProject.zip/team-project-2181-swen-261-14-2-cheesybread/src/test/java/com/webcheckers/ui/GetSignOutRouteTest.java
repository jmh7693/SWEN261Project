package com.webcheckers.ui;

import com.webcheckers.appl.PlayerLobby;
import com.webcheckers.model.Message;
import com.webcheckers.model.Player;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import spark.ModelAndView;
import spark.Response;
import spark.Session;
import spark.TemplateEngine;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;


public class GetSignOutRouteTest {

    static final String PLAYER_TEST_NAME = "test";
    private GetSignOutRoute signOutRoute;
    private spark.Request request;
    private spark.Session session;
    private Response response;
    private TemplateEngine engine;
    private PlayerLobby playerLobby;
    private Player player;

    /**
     * Sets up the mocks and dependencies
     */
    @BeforeEach
    public void setup(){
        request = mock(spark.Request.class);
        session = mock(Session.class);
        when(request.session()).thenReturn(session);

        response = mock(Response.class);
        engine = mock(TemplateEngine.class);
        playerLobby = new PlayerLobby();
        player = new Player(playerLobby);
        playerLobby.signIn(PLAYER_TEST_NAME,player);
        when(session.attribute(GetHomeRoute.PLAYER_NAME)).thenReturn(player);

        signOutRoute = new GetSignOutRoute(engine);
    }

    /**
     * Tests the signout functionality
     */
    @Test
    public void sign_out(){
        final MyModelAndView myModelView = new MyModelAndView();
        when(engine.render(any(ModelAndView.class))).thenAnswer(MyModelAndView.makeAnswer(myModelView));

        signOutRoute.handle(request,response);

        final Object model = myModelView.model;
        assertNotNull(model);
        assertTrue(model instanceof Map);

        final Map<String, Object> vm = (Map<String, Object>) model;

        assertEquals(GetSignOutRoute.SIGNOUT_MSG, ((Message)vm.get(GetSignOutRoute.MSG_ATTR)).getText() );
        assertEquals(GetHomeRoute.VIEW_HOME, myModelView.viewName);
        assertFalse(playerLobby.isSignedIn(player));
    }
}