package com.webcheckers.ui;
import com.sun.org.apache.xpath.internal.operations.Mod;
import com.webcheckers.appl.GameCenter;
import com.webcheckers.appl.PlayerLobby;
//import com.webcheckers.model.PendingMoves;
import com.webcheckers.appl.PlayerLobby;
import com.webcheckers.model.Player;
import javafx.geometry.Pos;
import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.mockito.ArgumentMatchers.any;

import spark.*;
import spark.TemplateEngine;

import java.io.IOException;
import java.util.Map;

public class PostSignInRouteTest {
    private PostSignInRoute CuT;

    private PlayerLobby playerLobby;
    //private GameLobby gameLobby;
    private GameCenter gameCenter;
    private Player player;
    private Request request;
    private Response response;
    private Session session;
    private TemplateEngine engine;

    @BeforeEach
    public void setup(){

        request = mock(Request.class);
        session = mock(Session.class);
        when(request.session()).thenReturn(session);
        engine = mock(TemplateEngine.class);
        player = mock(Player.class);
        playerLobby = new PlayerLobby();
        Player inUse = new Player(playerLobby);
        playerLobby.signIn("inUse", inUse);

        CuT = new PostSignInRoute(engine);

    }

    /**
     *
     */
    @Test
    public void test_new_signIn(){
        final MyModelAndView myModelAndView = new MyModelAndView();

        when(engine.render(any(ModelAndView.class))).thenAnswer(MyModelAndView.makeAnswer(myModelAndView));
        when(request.session()).thenReturn(session);

        when(session.attribute(GetHomeRoute.PLAYER_NAME)).thenReturn(player);
        when(request.queryParams(PostSignInRoute.NAME_ATTR)).thenReturn(PostSignInRoute.NAME_ATTR);

        CuT.handle(request, response);

        final Object model = myModelAndView.model;
        assertNotNull(model);
        assertTrue(model instanceof Map);

        final Map<String, Object> vm = (Map<String, Object>)model;

        assertEquals(GetHomeRoute.TITLE, vm.get(GetHomeRoute.TITLE_ATTR));
        assertEquals(player, session.attribute(GetHomeRoute.PLAYER_NAME));
        assertEquals(GetSignInRoute.VIEW_NAME, myModelAndView.viewName);
    }

    @Test
    public void test_name_input(){
        final MyModelAndView myModelAndView = new MyModelAndView();

        when(engine.render(any(ModelAndView.class))).thenAnswer(MyModelAndView.makeAnswer(myModelAndView));
        when(request.session()).thenReturn(session);

        when(session.attribute(GetHomeRoute.PLAYER_NAME)).thenReturn(player);

        when(request.queryParams(PostSignInRoute.NAME_ATTR)).thenReturn(PostSignInRoute.NAME_ATTR);

        when(player.signIn(GetHomeRoute.PLAYER_NAME)).thenReturn(true);

        CuT.handle(request, response);

        final Object model = myModelAndView.model;
        assertNotNull(model);
        assertTrue(model instanceof Map);
    }

    @Test
    public void test_not_valid_name_input(){
        final MyModelAndView myModelAndView = new MyModelAndView();

        when(engine.render(any(ModelAndView.class))).thenAnswer(MyModelAndView.makeAnswer(myModelAndView));
        when(request.session()).thenReturn(session);

        when(session.attribute(GetHomeRoute.PLAYER_NAME)).thenReturn(player);

        when(request.queryParams(PostSignInRoute.NAME_ATTR)).thenReturn(PostSignInRoute.NAME_ATTR);

        when(!player.checkName(request.queryParams(PostSignInRoute.NAME_ATTR))).thenReturn(true);

        CuT.handle(request, response);

        final Object model = myModelAndView.model;
        assertNotNull(model);
        assertTrue(model instanceof Map);
    }




}
