package com.webcheckers.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

import static org.mockito.Mockito.*;

@Tag("Model-tier")
public class BoardTest {
    private Board CuT;

    private Player redPlayer;
    private Player whitePlayer;

    @BeforeEach
    public void setup(){
        redPlayer = mock(Player.class);
        whitePlayer = mock(Player.class);
    }

    @Test
    public void ctor() {
        final Board CuT = new Board(redPlayer, whitePlayer);

        assertEquals(8, CuT.getRows().size());
        assertEquals(8, CuT.getRows().get(0).spaces.size());
    }

    @Test
    public void ctor_first_row() {
        final Board CuT = new Board(redPlayer, whitePlayer);

        assertFalse(CuT.getRows().get(0).spaces.get(0).validSpace);
        assertTrue(CuT.getRows().get(0).spaces.get(1).validSpace);
        assertEquals(new Piece(redPlayer, Piece.Color.RED, 0, 1), CuT.pieceAt(0,1));
    }
}
