package com.webcheckers.model;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class MessageTest {

    @Test
    public void gettersTest(){
        final Message message = new Message("test", Message.Type.info);

        assertEquals(true, message.getText().equals("test"));
        assertEquals(true, message.getType() == Message.Type.info);
    }
}
