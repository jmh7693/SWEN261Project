package com.webcheckers.appl;

import com.webcheckers.model.Player;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;


public class PlayerLobbyTest {

    @Test
    public void getPlayerTest(){
        PlayerLobby playerLobby = new PlayerLobby();
        Player p1 = new Player(playerLobby);
        Player p2 = new Player(playerLobby);
        Player p3 = new Player(playerLobby);
        Player test = new Player(playerLobby);


        playerLobby.signIn("one", p1);
        playerLobby.signIn("Two", p2);
        playerLobby.signIn("Three", p3);

        assertEquals(true, playerLobby.getPlayer("one").equals(p1));
        assertEquals(true, playerLobby.getPlayer("test") == null);
    }

    @Test
    public void hasPlayerTest(){
        PlayerLobby playerLobby = new PlayerLobby();
        Player p1 = new Player(playerLobby);
        Player p2 = new Player(playerLobby);
        Player p3 = new Player(playerLobby);
        Player test = new Player(playerLobby);


        playerLobby.signIn("one", p1);
        playerLobby.signIn("Two", p2);
        playerLobby.signIn("Three", p3);


        assertEquals(true, playerLobby.isSignedIn(p3));
        assertEquals(false, playerLobby.isSignedIn(test));
    }

}
