package com.webcheckers.appl;

import com.webcheckers.model.Player;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class GameCenterTest {

    private GameCenter gameCenter;
    private PlayerLobby playerLobby;

    private Player p1, p2;

    @BeforeEach
    public void setup() {
        gameCenter = new GameCenter();
        playerLobby = new PlayerLobby();
        p1 = playerLobby.newPlayer();
        p2 = playerLobby.newPlayer();
        p1.signIn("Player 1");
        p2.signIn("Plater 2");
    }

    @Test
    public void testPlayingYourself() {
        p1.signIn("Player");
        assertFalse(gameCenter.startGame(p1, p1), "Cannot play a game with yourself");
    }

    @Test
    public void testStartGame() {
        assertTrue(gameCenter.startGame(p1, p2), "Should be able to start a game");
    }

    @Test
    public void testAlreadyInGame() {
        Player p3 = playerLobby.newPlayer();
        p3.signIn("Player 3");
        gameCenter.startGame(p1, p2);
        assertFalse(gameCenter.startGame(p3, p1), "Should not be able to start game with someone already in a game");
    }

    @Test
    public void testGetGame() {
        gameCenter.startGame(p1, p2);
        assertNotNull(gameCenter.getGame(p1), "Should be able to get game for Player 1");
        assertNotNull(gameCenter.getGame(p2), "Should be able to get game for Player 2");
        assertEquals(gameCenter.getGame(p1), gameCenter.getGame(p2), "Game should be the same for either player");
    }


}
